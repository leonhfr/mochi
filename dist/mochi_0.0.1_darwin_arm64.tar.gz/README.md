# mochi

Synchronize markdown notes to mochi cards.
